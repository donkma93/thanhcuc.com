

<?php $__env->startSection('title', 'Cài đặt Website'); ?>

<?php $__env->startSection('header'); ?>
    <div>
        <h1 class="h3 mb-0">
            <i class="fas fa-cogs me-2"></i>
            Cài đặt Website
        </h1>
        <p class="text-muted mb-0">Quản lý các cài đặt chung của website</p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="row">
            <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $groupSettings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <?php switch($group):
                                    case ('general'): ?>
                                        <i class="fas fa-globe me-2"></i>Cài đặt chung
                                        <?php break; ?>
                                    <?php case ('contact'): ?>
                                        <i class="fas fa-phone me-2"></i>Thông tin liên hệ
                                        <?php break; ?>
                                    <?php case ('social'): ?>
                                        <i class="fas fa-share-alt me-2"></i>Mạng xã hội
                                        <?php break; ?>
                                    <?php case ('seo'): ?>
                                        <i class="fas fa-search me-2"></i>SEO
                                        <?php break; ?>
                                    <?php default: ?>
                                        <i class="fas fa-cog me-2"></i><?php echo e(ucfirst($group)); ?>

                                <?php endswitch; ?>
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php $__currentLoopData = $groupSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-3">
                                    <label for="setting_<?php echo e($setting->key); ?>" class="form-label">
                                        <?php echo e($setting->label); ?>

                                        <?php if($setting->description): ?>
                                            <i class="fas fa-info-circle text-muted ms-1" 
                                               title="<?php echo e($setting->description); ?>" 
                                               data-bs-toggle="tooltip"></i>
                                        <?php endif; ?>
                                    </label>
                                    
                                    <?php switch($setting->type):
                                        case ('text'): ?>
                                            <input type="text" 
                                                   class="form-control <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                   id="setting_<?php echo e($setting->key); ?>" 
                                                   name="settings[<?php echo e($setting->key); ?>]" 
                                                   value="<?php echo e(old('settings.' . $setting->key, $setting->value)); ?>"
                                                   placeholder="<?php echo e($setting->description); ?>">
                                            <?php break; ?>
                                            
                                        <?php case ('textarea'): ?>
                                            <textarea class="form-control <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                      id="setting_<?php echo e($setting->key); ?>" 
                                                      name="settings[<?php echo e($setting->key); ?>]" 
                                                      rows="3"
                                                      placeholder="<?php echo e($setting->description); ?>"><?php echo e(old('settings.' . $setting->key, $setting->value)); ?></textarea>
                                            <?php break; ?>
                                            
                                        <?php case ('image'): ?>
                                            <input type="file" 
                                                   class="form-control <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                   id="setting_<?php echo e($setting->key); ?>" 
                                                   name="settings[<?php echo e($setting->key); ?>]" 
                                                   accept="image/*">
                                            <?php if($setting->value): ?>
                                                <div class="mt-2">
                                                    <img src="<?php echo e(Storage::url($setting->value)); ?>" 
                                                         alt="<?php echo e($setting->label); ?>" 
                                                         class="img-thumbnail" 
                                                         style="max-width: 200px; max-height: 100px;">
                                                </div>
                                            <?php endif; ?>
                                            <?php break; ?>
                                            
                                        <?php case ('select'): ?>
                                            <select class="form-select <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                    id="setting_<?php echo e($setting->key); ?>" 
                                                    name="settings[<?php echo e($setting->key); ?>]">
                                                <?php if(isset($setting->options)): ?>
                                                    <?php $__currentLoopData = json_decode($setting->options, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionValue => $optionLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($optionValue); ?>" 
                                                                <?php echo e(old('settings.' . $setting->key, $setting->value) == $optionValue ? 'selected' : ''); ?>>
                                                            <?php echo e($optionLabel); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                            <?php break; ?>
                                            
                                        <?php case ('checkbox'): ?>
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" 
                                                       type="checkbox" 
                                                       id="setting_<?php echo e($setting->key); ?>" 
                                                       name="settings[<?php echo e($setting->key); ?>]" 
                                                       value="1"
                                                       <?php echo e(old('settings.' . $setting->key, $setting->value) ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="setting_<?php echo e($setting->key); ?>">
                                                    <?php echo e($setting->description); ?>

                                                </label>
                                            </div>
                                            <?php break; ?>
                                            
                                        <?php case ('color'): ?>
                                            <input type="color" 
                                                   class="form-control form-control-color <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                   id="setting_<?php echo e($setting->key); ?>" 
                                                   name="settings[<?php echo e($setting->key); ?>]" 
                                                   value="<?php echo e(old('settings.' . $setting->key, $setting->value)); ?>"
                                                   style="width: 60px; height: 40px;">
                                            <?php break; ?>
                                            
                                        <?php default: ?>
                                            <input type="text" 
                                                   class="form-control <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                   id="setting_<?php echo e($setting->key); ?>" 
                                                   name="settings[<?php echo e($setting->key); ?>]" 
                                                   value="<?php echo e(old('settings.' . $setting->key, $setting->value)); ?>">
                                    <?php endswitch; ?>
                                    
                                    <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                    <?php if($setting->description && $setting->type !== 'checkbox'): ?>
                                        <div class="form-text"><?php echo e($setting->description); ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body text-center">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-save me-2"></i>
                            Lưu Cài đặt
                        </button>
                        <button type="reset" class="btn btn-secondary btn-lg ms-2">
                            <i class="fas fa-undo me-2"></i>
                            Khôi phục
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
        
        // Image preview for file inputs
        const imageInputs = document.querySelectorAll('input[type="file"][accept*="image"]');
        imageInputs.forEach(input => {
            input.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        let preview = input.parentNode.querySelector('.preview-image');
                        if (!preview) {
                            preview = document.createElement('div');
                            preview.className = 'preview-image mt-2';
                            input.parentNode.appendChild(preview);
                        }
                        preview.innerHTML = `
                            <img src="${e.target.result}" 
                                 alt="Preview" 
                                 class="img-thumbnail" 
                                 style="max-width: 200px; max-height: 100px;">
                        `;
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
        
        // Form validation
        const form = document.querySelector('form');
        form.addEventListener('submit', function(e) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.classList.add('is-invalid');
                    isValid = false;
                } else {
                    field.classList.remove('is-invalid');
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                showAlert('error', 'Vui lòng điền đầy đủ các trường bắt buộc');
            }
        });
    });
    
    function showAlert(type, message) {
        const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
        const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
        
        const alert = document.createElement('div');
        alert.className = `alert ${alertClass} alert-dismissible fade show`;
        alert.innerHTML = `
            <i class="fas ${icon} me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        const container = document.querySelector('.main-content');
        container.insertBefore(alert, container.firstChild);
        
        // Auto dismiss after 5 seconds
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\donpv\Desktop\English\english-learning-app\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>