

<?php $__env->startSection('title', 'Quản lý Lịch Khai Giảng'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0 text-gray-800">Quản lý Lịch Khai Giảng</h1>
        <p class="text-muted">Quản lý các khóa học và lịch khai giảng</p>
    </div>
    <div>
        <a href="<?php echo e(route('admin.schedules.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Thêm Lịch Khai Giảng
        </a>
    </div>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.schedules.index')); ?>" class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Tìm kiếm</label>
                <input type="text" name="search" class="form-control" placeholder="Tên khóa học, giảng viên..." value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">Trình độ</label>
                <select name="level" class="form-select">
                    <option value="">Tất cả</option>
                    <?php $__currentLoopData = \App\Models\Schedule::LEVELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(request('level') == $key ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Trạng thái</label>
                <select name="status" class="form-select">
                    <option value="">Tất cả</option>
                    <?php $__currentLoopData = \App\Models\Schedule::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(request('status') == $key ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Loại khóa học</label>
                <select name="course_type" class="form-select">
                    <option value="">Tất cả</option>
                    <?php $__currentLoopData = \App\Models\Schedule::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(request('course_type') == $key ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">&nbsp;</label>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-outline-primary">
                        <i class="fas fa-search me-1"></i>Lọc
                    </button>
                    <a href="<?php echo e(route('admin.schedules.index')); ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-times me-1"></i>Xóa bộ lọc
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Bulk Actions -->
<div class="card mb-4">
    <div class="card-body">
        <form id="bulkActionForm" method="POST" action="<?php echo e(route('admin.schedules.bulk-action')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row align-items-center">
                <div class="col-md-3">
                    <select name="action" class="form-select" required>
                        <option value="">Chọn hành động</option>
                        <option value="publish">Xuất bản</option>
                        <option value="unpublish">Chuyển về bản nháp</option>
                        <option value="feature">Đánh dấu nổi bật</option>
                        <option value="unfeature">Bỏ đánh dấu nổi bật</option>
                        <option value="delete">Xóa</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-warning" 
                            data-confirm="Bạn có chắc chắn muốn thực hiện hành động này?"
                            data-confirm-type="warning">
                        <i class="fas fa-bolt me-1"></i>Thực hiện
                    </button>
                </div>
                <div class="col-md-6 text-end">
                    <small class="text-muted">
                        <span id="selectedCount">0</span> mục được chọn
                    </small>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Schedules Table -->
<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">
            <i class="fas fa-calendar-alt me-2"></i>Danh sách Lịch Khai Giảng
            <span class="badge bg-primary ms-2"><?php echo e($schedules->total()); ?></span>
        </h5>
    </div>
    <div class="card-body p-0">
        <?php if($schedules->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th width="50">
                                <input type="checkbox" id="selectAll" class="form-check-input">
                            </th>
                            <th>Khóa học</th>
                            <th>Trình độ</th>
                            <th>Giảng viên</th>
                            <th>Thời gian</th>
                            <th>Học viên</th>
                            <th>Học phí</th>
                            <th>Trạng thái</th>
                            <th width="150">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="selected_ids[]" value="<?php echo e($schedule->id); ?>" class="form-check-input schedule-checkbox">
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <?php if($schedule->teacher_avatar): ?>
                                            <img src="<?php echo e(Storage::url($schedule->teacher_avatar)); ?>" alt="Avatar" class="rounded-circle me-2" width="40" height="40">
                                        <?php else: ?>
                                            <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 40px; height: 40px;">
                                                <i class="fas fa-user text-white"></i>
                                            </div>
                                        <?php endif; ?>
                                        <div>
                                            <h6 class="mb-0"><?php echo e($schedule->title); ?></h6>
                                            <small class="text-muted"><?php echo e(Str::limit($schedule->description, 50)); ?></small>
                                            <?php if($schedule->is_featured): ?>
                                                <span class="badge bg-warning text-dark ms-1">Nổi bật</span>
                                            <?php endif; ?>
                                            <?php if($schedule->is_popular): ?>
                                                <span class="badge bg-info text-white ms-1">Phổ biến</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-secondary"><?php echo e($schedule->level_name); ?></span>
                                </td>
                                <td>
                                    <div>
                                        <strong><?php echo e($schedule->teacher_name); ?></strong>
                                        <?php if($schedule->teacher_title): ?>
                                            <br><small class="text-muted"><?php echo e($schedule->teacher_title); ?></small>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <strong><?php echo e($schedule->start_date->format('d/m/Y')); ?></strong>
                                        <br><small class="text-muted"><?php echo e($schedule->start_time); ?> - <?php echo e($schedule->end_time); ?></small>
                                        <br><small class="text-muted"><?php echo e($schedule->formatted_schedule_days); ?></small>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-center">
                                        <div class="fw-bold"><?php echo e($schedule->current_students); ?>/<?php echo e($schedule->max_students); ?></div>
                                        <div class="progress mt-1" style="height: 4px;">
                                            <div class="progress-bar <?php echo e($schedule->badge_class); ?>" style="width: <?php echo e($schedule->availability_percentage); ?>%"></div>
                                        </div>
                                        <small class="text-muted"><?php echo e($schedule->available_spots); ?> chỗ trống</small>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <strong class="text-primary"><?php echo e($schedule->formatted_price); ?></strong>
                                        <?php if($schedule->original_price && $schedule->original_price > $schedule->price): ?>
                                            <br><small class="text-muted text-decoration-line-through"><?php echo e($schedule->formatted_original_price); ?></small>
                                            <br><small class="text-success">-<?php echo e($schedule->discount_percentage); ?>%</small>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <?php switch($schedule->status):
                                        case ('published'): ?>
                                            <span class="badge bg-success"><?php echo e($schedule->status_name); ?></span>
                                            <?php break; ?>
                                        <?php case ('draft'): ?>
                                            <span class="badge bg-secondary"><?php echo e($schedule->status_name); ?></span>
                                            <?php break; ?>
                                        <?php case ('full'): ?>
                                            <span class="badge bg-warning text-dark"><?php echo e($schedule->status_name); ?></span>
                                            <?php break; ?>
                                        <?php case ('cancelled'): ?>
                                            <span class="badge bg-danger"><?php echo e($schedule->status_name); ?></span>
                                            <?php break; ?>
                                        <?php case ('completed'): ?>
                                            <span class="badge bg-info"><?php echo e($schedule->status_name); ?></span>
                                            <?php break; ?>
                                        <?php default: ?>
                                            <span class="badge bg-light text-dark"><?php echo e($schedule->status_name); ?></span>
                                    <?php endswitch; ?>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('admin.schedules.show', $schedule)); ?>" class="btn btn-sm btn-outline-info" title="Xem chi tiết">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.schedules.edit', $schedule)); ?>" class="btn btn-sm btn-outline-primary" title="Chỉnh sửa">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="<?php echo e(route('admin.schedules.duplicate', $schedule)); ?>">
                                                    <i class="fas fa-copy me-2"></i>Sao chép
                                                </a></li>
                                                <?php if($schedule->trashed()): ?>
                                                    <li><a class="dropdown-item text-success" href="<?php echo e(route('admin.schedules.restore', $schedule->id)); ?>">
                                                        <i class="fas fa-undo me-2"></i>Khôi phục
                                                    </a></li>
                                                    <li><hr class="dropdown-divider"></li>
                                                    <li><a class="dropdown-item text-danger" 
                                                           href="<?php echo e(route('admin.schedules.force-delete', $schedule->id)); ?>" 
                                                           data-confirm="Bạn có chắc chắn muốn xóa vĩnh viễn? Hành động này không thể hoàn tác!"
                                                           data-confirm-type="danger">
                                                        <i class="fas fa-trash-alt me-2"></i>Xóa vĩnh viễn
                                                    </a></li>
                                                <?php else: ?>
                                                    <li><hr class="dropdown-divider"></li>
                                                    <li><a class="dropdown-item text-danger" href="#" onclick="deleteSchedule(<?php echo e($schedule->id); ?>)">
                                                        <i class="fas fa-trash me-2"></i>Xóa
                                                    </a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">Không có lịch khai giảng nào</h5>
                <p class="text-muted">Hãy tạo lịch khai giảng đầu tiên của bạn!</p>
                <a href="<?php echo e(route('admin.schedules.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Thêm Lịch Khai Giảng
                </a>
            </div>
        <?php endif; ?>
    </div>
    
    <?php if($schedules->hasPages()): ?>
        <div class="card-footer">
            <?php echo e($schedules->links()); ?>

        </div>
    <?php endif; ?>
</div>

<!-- Delete Form -->
<form id="deleteForm" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Select all functionality
    const selectAllCheckbox = document.getElementById('selectAll');
    const scheduleCheckboxes = document.querySelectorAll('.schedule-checkbox');
    const selectedCountSpan = document.getElementById('selectedCount');
    const bulkActionForm = document.getElementById('bulkActionForm');

    selectAllCheckbox.addEventListener('change', function() {
        scheduleCheckboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
        });
        updateSelectedCount();
    });

    scheduleCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateSelectedCount);
    });

    function updateSelectedCount() {
        const selectedCheckboxes = document.querySelectorAll('.schedule-checkbox:checked');
        selectedCountSpan.textContent = selectedCheckboxes.length;
        
        // Update select all checkbox state
        if (selectedCheckboxes.length === 0) {
            selectAllCheckbox.indeterminate = false;
            selectAllCheckbox.checked = false;
        } else if (selectedCheckboxes.length === scheduleCheckboxes.length) {
            selectAllCheckbox.indeterminate = false;
            selectAllCheckbox.checked = true;
        } else {
            selectAllCheckbox.indeterminate = true;
        }
    }

    // Bulk action form submission
    bulkActionForm.addEventListener('submit', function(e) {
        const selectedCheckboxes = document.querySelectorAll('.schedule-checkbox:checked');
        if (selectedCheckboxes.length === 0) {
            e.preventDefault();
            alert('Vui lòng chọn ít nhất một mục để thực hiện hành động.');
            return;
        }

        // Add selected IDs to form
        selectedCheckboxes.forEach(checkbox => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'selected_ids[]';
            input.value = checkbox.value;
            this.appendChild(input);
        });
    });

    // Delete function
    window.deleteSchedule = function(id) {
        confirmDelete('Lịch khai giảng này', function() {
            const form = document.getElementById('deleteForm');
            form.action = `/admin/schedules/${id}`;
            form.submit();
        });
    };
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\donpv\Desktop\English\english-learning-app\resources\views/admin/schedules/index.blade.php ENDPATH**/ ?>