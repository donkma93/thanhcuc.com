

<?php $__env->startSection('title', 'Quản lý khóa học'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-0 text-gray-800">Quản lý khóa học</h1>
        <p class="text-muted">Danh sách tất cả khóa học</p>
    </div>
    <div>
        <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Thêm khóa học
        </a>
    </div>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.courses.index')); ?>" class="row g-3">
            <div class="col-md-4">
                <label for="search" class="form-label">Tìm kiếm</label>
                <input type="text" class="form-control" id="search" name="search" 
                       placeholder="Tên khóa học, mô tả..." value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-3">
                <label for="category" class="form-label">Danh mục</label>
                <select class="form-select" id="category" name="category">
                    <option value="">Tất cả danh mục</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category); ?>" <?php echo e(request('category') === $category ? 'selected' : ''); ?>>
                            <?php echo e($category); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="status" class="form-label">Trạng thái</label>
                <select class="form-select" id="status" name="status">
                    <option value="">Tất cả</option>
                    <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Hoạt động</option>
                    <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Không hoạt động</option>
                </select>
            </div>
            <div class="col-md-3 d-flex align-items-end gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search me-2"></i>Tìm kiếm
                </button>
                <a href="<?php echo e(route('admin.courses.index')); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-times me-2"></i>Xóa bộ lọc
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Bulk Actions -->
<?php if($courses->count() > 0): ?>
    <div class="card mb-4">
        <div class="card-body">
            <form id="bulkActionForm" method="POST" action="<?php echo e(route('admin.courses.bulk-action')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label for="bulkAction" class="form-label">Thao tác hàng loạt</label>
                        <select class="form-select" id="bulkAction" name="action" required>
                            <option value="">Chọn thao tác</option>
                            <option value="activate">Kích hoạt</option>
                            <option value="deactivate">Vô hiệu hóa</option>
                            <option value="delete">Xóa</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-warning" onclick="return confirmBulkAction()">
                            <i class="fas fa-bolt me-2"></i>Thực hiện
                        </button>
                    </div>
                    <div class="col-md-6 text-end">
                        <small class="text-muted">
                            <span id="selectedCount">0</span> mục được chọn
                        </small>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>

<!-- Courses Table -->
<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">
            <i class="fas fa-graduation-cap me-2"></i>Danh sách khóa học
            <span class="badge bg-primary ms-2"><?php echo e($courses->total()); ?></span>
        </h5>
    </div>
    <div class="card-body p-0">
        <?php if($courses->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th width="50">
                                <input type="checkbox" id="selectAll" class="form-check-input">
                            </th>
                            <th>Khóa học</th>
                            <th>Danh mục</th>
                            <th>Giá</th>
                            <th>Trạng thái</th>
                            <th>Thứ tự</th>
                            <th width="150">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="selected_courses[]" 
                                           value="<?php echo e($course->id); ?>" class="form-check-input course-checkbox">
                                </td>
                                <td>
                                    <div class="d-flex align-items-start">
                                        <?php if($course->image): ?>
                                            <img src="<?php echo e(asset('storage/' . $course->image)); ?>" 
                                                 alt="<?php echo e($course->name); ?>" 
                                                 class="rounded me-3" 
                                                 style="width: 50px; height: 50px; object-fit: cover;">
                                        <?php else: ?>
                                            <div class="bg-secondary rounded d-flex align-items-center justify-content-center me-3" 
                                                 style="width: 50px; height: 50px; min-width: 50px;">
                                                <i class="fas fa-graduation-cap text-white"></i>
                                            </div>
                                        <?php endif; ?>
                                        <div>
                                            <h6 class="mb-1 fw-bold"><?php echo e($course->name); ?></h6>
                                            <?php if($course->short_description): ?>
                                                <small class="text-muted"><?php echo e(Str::limit($course->short_description, 60)); ?></small>
                                            <?php endif; ?>
                                            <br>
                                            <?php if($course->level): ?>
                                                <span class="badge bg-light text-dark small"><?php echo e($course->level); ?></span>
                                            <?php endif; ?>
                                            <?php if($course->duration_hours): ?>
                                                <span class="badge bg-info text-white small"><?php echo e($course->duration_hours); ?>h</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-secondary">
                                        <?php echo e($course->category); ?>

                                    </span>
                                </td>
                                <td>
                                    <?php if($course->price): ?>
                                        <span class="fw-bold text-success"><?php echo e(number_format($course->price, 0, ',', '.')); ?>đ</span>
                                    <?php else: ?>
                                        <span class="text-muted">Liên hệ</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($course->is_active): ?>
                                        <span class="badge bg-success">Hoạt động</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Không hoạt động</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark"><?php echo e($course->sort_order); ?></span>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('admin.courses.show', $course)); ?>" 
                                           class="btn btn-sm btn-outline-info" title="Xem chi tiết">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.courses.edit', $course)); ?>" 
                                           class="btn btn-sm btn-outline-primary" title="Chỉnh sửa">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <?php if(!$course->is_active): ?>
                                                    <li>
                                                        <form action="<?php echo e(route('admin.courses.update', $course)); ?>" method="POST" class="d-inline">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <input type="hidden" name="is_active" value="1">
                                                            <input type="hidden" name="name" value="<?php echo e($course->name); ?>">
                                                            <input type="hidden" name="category" value="<?php echo e($course->category); ?>">
                                                            <input type="hidden" name="description" value="<?php echo e($course->description); ?>">
                                                            <button type="submit" class="dropdown-item text-success">
                                                                <i class="fas fa-check me-2"></i>Kích hoạt
                                                            </button>
                                                        </form>
                                                    </li>
                                                <?php else: ?>
                                                    <li>
                                                        <form action="<?php echo e(route('admin.courses.update', $course)); ?>" method="POST" class="d-inline">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <input type="hidden" name="is_active" value="0">
                                                            <input type="hidden" name="name" value="<?php echo e($course->name); ?>">
                                                            <input type="hidden" name="category" value="<?php echo e($course->category); ?>">
                                                            <input type="hidden" name="description" value="<?php echo e($course->description); ?>">
                                                            <button type="submit" class="dropdown-item text-warning">
                                                                <i class="fas fa-pause me-2"></i>Vô hiệu hóa
                                                            </button>
                                                        </form>
                                                    </li>
                                                <?php endif; ?>
                                                <li><hr class="dropdown-divider"></li>
                                                <li>
                                                    <form action="<?php echo e(route('admin.courses.destroy', $course)); ?>" method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="dropdown-item text-danger" 
                                                                data-delete="Khóa học <?php echo e($course->name); ?>">
                                                            <i class="fas fa-trash me-2"></i>Xóa
                                                        </button>
                                                    </form>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php if($courses->hasPages()): ?>
                <div class="card-footer bg-white border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <small class="text-muted">
                                Hiển thị <?php echo e($courses->firstItem()); ?> - <?php echo e($courses->lastItem()); ?> 
                                trong tổng số <?php echo e($courses->total()); ?> kết quả
                            </small>
                        </div>
                        <div>
                            <?php echo e($courses->appends(request()->query())->links('pagination.bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-graduation-cap fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">Không có khóa học nào</h5>
                <p class="text-muted">
                    <?php if(request()->hasAny(['search', 'category', 'status'])): ?>
                        Không tìm thấy khóa học nào phù hợp với bộ lọc.
                    <?php else: ?>
                        Chưa có khóa học nào được tạo.
                    <?php endif; ?>
                </p>
                <?php if(request()->hasAny(['search', 'category', 'status'])): ?>
                    <a href="<?php echo e(route('admin.courses.index')); ?>" class="btn btn-primary">
                        <i class="fas fa-times me-2"></i>Xóa bộ lọc
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Tạo khóa học đầu tiên
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Select all functionality
    document.getElementById('selectAll').addEventListener('change', function() {
        const checkboxes = document.querySelectorAll('.course-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
        });
        updateSelectedCount();
    });

    // Update selected count
    function updateSelectedCount() {
        const selectedCheckboxes = document.querySelectorAll('.course-checkbox:checked');
        const count = selectedCheckboxes.length;
        document.getElementById('selectedCount').textContent = count;
        
        // Update bulk action form
        const bulkForm = document.getElementById('bulkActionForm');
        if (bulkForm) {
            // Remove existing hidden inputs
            const existingInputs = bulkForm.querySelectorAll('input[name="selected_courses[]"]');
            existingInputs.forEach(input => input.remove());
            
            // Add new hidden inputs
            selectedCheckboxes.forEach(checkbox => {
                const hiddenInput = document.createElement('input');
                hiddenInput.type = 'hidden';
                hiddenInput.name = 'selected_courses[]';
                hiddenInput.value = checkbox.value;
                bulkForm.appendChild(hiddenInput);
            });
        }
    }

    // Add event listeners to individual checkboxes
    document.querySelectorAll('.course-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', updateSelectedCount);
    });

    // Confirm bulk action
    function confirmBulkAction() {
        const selectedCount = document.querySelectorAll('.course-checkbox:checked').length;
        const action = document.getElementById('bulkAction').value;
        
        if (selectedCount === 0) {
            alert('Vui lòng chọn ít nhất một khóa học.');
            return false;
        }
        
        if (!action) {
            alert('Vui lòng chọn thao tác.');
            return false;
        }
        
        let message = '';
        switch (action) {
            case 'activate':
                message = `Kích hoạt ${selectedCount} khóa học?`;
                break;
            case 'deactivate':
                message = `Vô hiệu hóa ${selectedCount} khóa học?`;
                break;
            case 'delete':
                message = `Xóa ${selectedCount} khóa học? Hành động này không thể hoàn tác.`;
                break;
        }
        
        return confirmAction(message);
    }
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* Pagination Styling */
.pagination {
    margin-bottom: 0;
    gap: 4px;
}

.pagination .page-item {
    margin: 0;
}

.pagination .page-link {
    color: #6c757d;
    border: 1px solid #dee2e6;
    padding: 0.375rem 0.75rem;
    border-radius: 6px;
    transition: all 0.2s ease;
    font-size: 0.875rem;
    min-width: 40px;
    text-align: center;
}

.pagination .page-link:hover {
    color: #495057;
    background-color: #e9ecef;
    border-color: #adb5bd;
    text-decoration: none;
}

.pagination .page-item.active .page-link {
    background-color: #007bff;
    border-color: #007bff;
    color: white;
    font-weight: 600;
}

.pagination .page-item.disabled .page-link {
    color: #adb5bd;
    background-color: #fff;
    border-color: #dee2e6;
    cursor: not-allowed;
}

.pagination .page-link i {
    font-size: 0.75rem;
}

/* Card Footer Styling */
.card-footer {
    padding: 1rem 1.25rem;
    background-color: #f8f9fa;
    border-top: 1px solid #dee2e6;
}

.card-footer.bg-white {
    background-color: #fff !important;
}

/* Responsive pagination */
@media (max-width: 576px) {
    .pagination {
        justify-content: center;
    }
    
    .d-flex.justify-content-between {
        flex-direction: column;
        gap: 1rem;
        text-align: center;
    }
}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\donpv\Desktop\English\english-learning-app\resources\views/admin/courses/index.blade.php ENDPATH**/ ?>