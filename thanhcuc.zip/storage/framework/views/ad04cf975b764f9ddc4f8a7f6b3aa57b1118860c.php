

<?php $__env->startSection('title', 'Demo MessageBox'); ?>

<?php $__env->startSection('header'); ?>
    <div>
        <h1 class="h3 mb-0">
            <i class="fas fa-comment-dots me-2"></i>
            Demo MessageBox
        </h1>
        <p class="text-muted mb-0">Kiểm tra các loại thông báo và messagebox</p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <!-- Basic Messages -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-bell me-2"></i>
                        Thông báo cơ bản
                    </h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <button type="button" class="btn btn-success" onclick="testSuccess()">
                            <i class="fas fa-check-circle me-2"></i>Thành công
                        </button>
                        <button type="button" class="btn btn-danger" onclick="testError()">
                            <i class="fas fa-times-circle me-2"></i>Lỗi
                        </button>
                        <button type="button" class="btn btn-warning" onclick="testWarning()">
                            <i class="fas fa-exclamation-triangle me-2"></i>Cảnh báo
                        </button>
                        <button type="button" class="btn btn-info" onclick="testInfo()">
                            <i class="fas fa-info-circle me-2"></i>Thông tin
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Confirmation Dialogs -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-question-circle me-2"></i>
                        Hộp thoại xác nhận
                    </h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <button type="button" class="btn btn-primary" onclick="testConfirm()">
                            <i class="fas fa-question me-2"></i>Xác nhận thông thường
                        </button>
                        <button type="button" class="btn btn-danger" onclick="testConfirmDelete()">
                            <i class="fas fa-trash me-2"></i>Xác nhận xóa
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Toast Notifications -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-bread-slice me-2"></i>
                        Toast Notifications
                    </h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <button type="button" class="btn btn-outline-success" onclick="testToastSuccess()">
                            <i class="fas fa-check me-2"></i>Toast Thành công
                        </button>
                        <button type="button" class="btn btn-outline-danger" onclick="testToastError()">
                            <i class="fas fa-times me-2"></i>Toast Lỗi
                        </button>
                        <button type="button" class="btn btn-outline-warning" onclick="testToastWarning()">
                            <i class="fas fa-exclamation me-2"></i>Toast Cảnh báo
                        </button>
                        <button type="button" class="btn btn-outline-info" onclick="testToastInfo()">
                            <i class="fas fa-info me-2"></i>Toast Thông tin
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Loading & Special -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-cog me-2"></i>
                        Loading & Đặc biệt
                    </h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <button type="button" class="btn btn-secondary" onclick="testLoading()">
                            <i class="fas fa-spinner me-2"></i>Loading
                        </button>
                        <button type="button" class="btn btn-dark" onclick="testCustom()">
                            <i class="fas fa-magic me-2"></i>Tùy chỉnh
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Code Examples -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-code me-2"></i>
                        Cách sử dụng
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>JavaScript:</h6>
                            <pre class="bg-light p-3 rounded"><code>// Thông báo cơ bản
MessageBox.success('Thành công!', 'Dữ liệu đã được lưu');
MessageBox.error('Lỗi!', 'Có lỗi xảy ra');
MessageBox.warning('Cảnh báo!', 'Vui lòng kiểm tra lại');
MessageBox.info('Thông tin', 'Đây là thông tin quan trọng');

// Toast notifications
MessageBox.toast.success('Lưu thành công!');
MessageBox.toast.error('Có lỗi xảy ra!');

// Xác nhận
MessageBox.confirm('Bạn có chắc?', 'Hành động này sẽ thay đổi dữ liệu')
    .then((result) => {
        if (result.isConfirmed) {
            // Thực hiện hành động
        }
    });

// Xác nhận xóa
MessageBox.confirmDelete()
    .then((result) => {
        if (result.isConfirmed) {
            // Thực hiện xóa
        }
    });

// Loading
MessageBox.loading('Đang xử lý...');
// Đóng loading
MessageBox.close();</code></pre>
                        </div>
                        <div class="col-md-6">
                            <h6>Laravel Controller:</h6>
                            <pre class="bg-light p-3 rounded"><code>// Thành công
return redirect()->back()
    ->with('success', 'Dữ liệu đã được lưu thành công!');

// Lỗi
return redirect()->back()
    ->with('error', 'Có lỗi xảy ra khi lưu dữ liệu!');

// Cảnh báo
return redirect()->back()
    ->with('warning', 'Vui lòng kiểm tra lại thông tin!');

// Thông tin
return redirect()->back()
    ->with('info', 'Thông tin đã được cập nhật!');</code></pre>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Test functions for demo
    function testSuccess() {
        MessageBox.success('Thành công!', 'Dữ liệu đã được lưu thành công vào hệ thống.');
    }

    function testError() {
        MessageBox.error('Có lỗi xảy ra!', 'Không thể kết nối đến máy chủ. Vui lòng thử lại sau.');
    }

    function testWarning() {
        MessageBox.warning('Cảnh báo!', 'Bạn đang thực hiện một hành động có thể ảnh hưởng đến dữ liệu.');
    }

    function testInfo() {
        MessageBox.info('Thông tin', 'Hệ thống sẽ được bảo trì vào 2:00 AM ngày mai.');
    }

    function testConfirm() {
        MessageBox.confirm('Bạn có chắc chắn?', 'Hành động này sẽ thay đổi cài đặt hệ thống.')
            .then((result) => {
                if (result.isConfirmed) {
                    MessageBox.toast.success('Đã xác nhận thành công!');
                } else {
                    MessageBox.toast.info('Đã hủy hành động.');
                }
            });
    }

    function testConfirmDelete() {
        MessageBox.confirmDelete('Xóa người dùng này?', 'Tất cả dữ liệu liên quan sẽ bị xóa vĩnh viễn!')
            .then((result) => {
                if (result.isConfirmed) {
                    MessageBox.toast.success('Đã xóa thành công!');
                } else {
                    MessageBox.toast.info('Đã hủy việc xóa.');
                }
            });
    }

    function testToastSuccess() {
        MessageBox.toast.success('Lưu dữ liệu thành công!');
    }

    function testToastError() {
        MessageBox.toast.error('Không thể tải dữ liệu!');
    }

    function testToastWarning() {
        MessageBox.toast.warning('Dung lượng sắp hết!');
    }

    function testToastInfo() {
        MessageBox.toast.info('Có 3 thông báo mới.');
    }

    function testLoading() {
        MessageBox.loading('Đang tải dữ liệu...');
        
        // Giả lập loading 3 giây
        setTimeout(() => {
            MessageBox.close();
            MessageBox.toast.success('Tải dữ liệu hoàn tất!');
        }, 3000);
    }

    function testCustom() {
        Swal.fire({
            title: 'Messagebox tùy chỉnh',
            html: `
                <div class="text-start">
                    <p><i class="fas fa-star text-warning"></i> Tính năng đặc biệt</p>
                    <p><i class="fas fa-shield-alt text-success"></i> Bảo mật cao</p>
                    <p><i class="fas fa-rocket text-primary"></i> Hiệu suất tối ưu</p>
                </div>
            `,
            icon: 'info',
            confirmButtonText: 'Tuyệt vời!',
            confirmButtonColor: '#F9D200',
            background: '#fff',
            backdrop: `
                rgba(0,0,123,0.4)
                url("data:image/svg+xml,%3csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3e%3cg fill='none' fill-rule='evenodd'%3e%3cg fill='%23ffffff' fill-opacity='0.1' fill-rule='nonzero'%3e%3ccircle cx='30' cy='30' r='30'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e")
                left top
                no-repeat
            `
        });
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\donpv\Desktop\English\english-learning-app\resources\views/admin/demo/messagebox.blade.php ENDPATH**/ ?>