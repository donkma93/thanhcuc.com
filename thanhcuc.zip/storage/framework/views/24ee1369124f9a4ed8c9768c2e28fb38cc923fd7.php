

<?php $__env->startSection('title', 'Quản lý Về Chúng Tôi'); ?>

<?php $__env->startSection('header'); ?>
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h1 class="h3 mb-0">
                <i class="fas fa-users me-2"></i>
                Quản lý Về Chúng Tôi
            </h1>
            <p class="text-muted mb-0">Quản lý thông tin trang Về chúng tôi</p>
        </div>
        <div>
            <button type="button" class="btn btn-warning" onclick="resetToDefault()">
                <i class="fas fa-undo me-2"></i>
                Khôi phục mặc định
            </button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('admin.about.update')); ?>" method="POST" enctype="multipart/form-data" id="aboutForm">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="row">
            <!-- Thông tin cơ bản -->
            <div class="col-lg-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-info-circle me-2"></i>Thông tin cơ bản
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $aboutSettings->where('sort_order', '<=', 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-3">
                                <label for="setting_<?php echo e($setting->key); ?>" class="form-label">
                                    <?php echo e($setting->label); ?>

                                    <?php if(in_array($setting->key, ['about_page_title', 'about_page_subtitle', 'about_overview_title', 'about_overview_content'])): ?>
                                        <span class="text-danger">*</span>
                                    <?php endif; ?>
                                    <?php if($setting->description): ?>
                                        <i class="fas fa-info-circle text-muted ms-1" 
                                           title="<?php echo e($setting->description); ?>" 
                                           data-bs-toggle="tooltip"></i>
                                    <?php endif; ?>
                                </label>
                                
                                <?php if($setting->type === 'text'): ?>
                                    <input type="text" 
                                           class="form-control <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="setting_<?php echo e($setting->key); ?>" 
                                           name="settings[<?php echo e($setting->key); ?>]" 
                                           value="<?php echo e(old('settings.' . $setting->key, $setting->value)); ?>"
                                           placeholder="<?php echo e($setting->description); ?>"
                                           <?php if(in_array($setting->key, ['about_page_title', 'about_overview_title'])): ?> required <?php endif; ?>>
                                <?php elseif($setting->type === 'textarea'): ?>
                                    <textarea class="form-control <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                              id="setting_<?php echo e($setting->key); ?>" 
                                              name="settings[<?php echo e($setting->key); ?>]" 
                                              rows="4"
                                              placeholder="<?php echo e($setting->description); ?>"
                                              <?php if(in_array($setting->key, ['about_page_subtitle', 'about_overview_content'])): ?> required <?php endif; ?>><?php echo e(old('settings.' . $setting->key, $setting->value)); ?></textarea>
                                <?php endif; ?>
                                
                                <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                                <?php if($setting->description && $setting->type !== 'checkbox'): ?>
                                    <div class="form-text"><?php echo e($setting->description); ?></div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <!-- Sứ mệnh & Tầm nhìn -->
            <div class="col-lg-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-bullseye me-2"></i>Sứ mệnh & Tầm nhìn
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $aboutSettings->whereIn('sort_order', [5, 6]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-3">
                                <label for="setting_<?php echo e($setting->key); ?>" class="form-label">
                                    <?php echo e($setting->label); ?>

                                    <span class="text-danger">*</span>
                                    <?php if($setting->description): ?>
                                        <i class="fas fa-info-circle text-muted ms-1" 
                                           title="<?php echo e($setting->description); ?>" 
                                           data-bs-toggle="tooltip"></i>
                                    <?php endif; ?>
                                </label>
                                
                                <textarea class="form-control <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                          id="setting_<?php echo e($setting->key); ?>" 
                                          name="settings[<?php echo e($setting->key); ?>]" 
                                          rows="4"
                                          placeholder="<?php echo e($setting->description); ?>"
                                          required><?php echo e(old('settings.' . $setting->key, $setting->value)); ?></textarea>
                                
                                <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                                <?php if($setting->description): ?>
                                    <div class="form-text"><?php echo e($setting->description); ?></div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <!-- Call-to-Action -->
            <div class="col-lg-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-bullhorn me-2"></i>Call-to-Action
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $aboutSettings->whereIn('sort_order', [10, 11]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-3">
                                <label for="setting_<?php echo e($setting->key); ?>" class="form-label">
                                    <?php echo e($setting->label); ?>

                                    <span class="text-danger">*</span>
                                    <?php if($setting->description): ?>
                                        <i class="fas fa-info-circle text-muted ms-1" 
                                           title="<?php echo e($setting->description); ?>" 
                                           data-bs-toggle="tooltip"></i>
                                    <?php endif; ?>
                                </label>
                                
                                <?php if($setting->type === 'text'): ?>
                                    <input type="text" 
                                           class="form-control <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="setting_<?php echo e($setting->key); ?>" 
                                           name="settings[<?php echo e($setting->key); ?>]" 
                                           value="<?php echo e(old('settings.' . $setting->key, $setting->value)); ?>"
                                           placeholder="<?php echo e($setting->description); ?>"
                                           required>
                                <?php else: ?>
                                    <textarea class="form-control <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                              id="setting_<?php echo e($setting->key); ?>" 
                                              name="settings[<?php echo e($setting->key); ?>]" 
                                              rows="3"
                                              placeholder="<?php echo e($setting->description); ?>"
                                              required><?php echo e(old('settings.' . $setting->key, $setting->value)); ?></textarea>
                                <?php endif; ?>
                                
                                <?php $__errorArgs = ['settings.' . $setting->key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                                <?php if($setting->description): ?>
                                    <div class="form-text"><?php echo e($setting->description); ?></div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <!-- Giá trị cốt lõi -->
            <div class="col-lg-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-heart me-2"></i>Giá trị cốt lõi
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php
                            $coreValuesSetting = $aboutSettings->where('key', 'about_core_values')->first();
                            $coreValues = $coreValuesSetting ? json_decode($coreValuesSetting->value, true) : [];
                        ?>
                        
                        <div id="core-values-container">
                            <?php $__currentLoopData = $coreValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="core-value-item border rounded p-3 mb-3">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label class="form-label">Icon (FontAwesome)</label>
                                            <input type="text" 
                                                   class="form-control" 
                                                   name="core_values[<?php echo e($index); ?>][icon]" 
                                                   value="<?php echo e($value['icon'] ?? ''); ?>"
                                                   placeholder="fas fa-heart">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Tiêu đề</label>
                                            <input type="text" 
                                                   class="form-control" 
                                                   name="core_values[<?php echo e($index); ?>][title]" 
                                                   value="<?php echo e($value['title'] ?? ''); ?>"
                                                   placeholder="Tận Tâm">
                                        </div>
                                        <div class="col-md-5">
                                            <label class="form-label">Mô tả</label>
                                            <textarea class="form-control" 
                                                      name="core_values[<?php echo e($index); ?>][description]" 
                                                      rows="2"
                                                      placeholder="Mô tả giá trị cốt lõi"><?php echo e($value['description'] ?? ''); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <input type="hidden" name="settings[about_core_values]" id="core_values_json">
                    </div>
                </div>
            </div>

            <!-- Thành tựu -->
            <div class="col-lg-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-trophy me-2"></i>Thành tựu đạt được
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php
                            $achievementsSetting = $aboutSettings->where('key', 'about_achievements')->first();
                            $achievements = $achievementsSetting ? json_decode($achievementsSetting->value, true) : [];
                        ?>
                        
                        <div id="achievements-container">
                            <?php $__currentLoopData = $achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="achievement-item border rounded p-3 mb-3">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label class="form-label">Số liệu</label>
                                            <input type="text" 
                                                   class="form-control" 
                                                   name="achievements[<?php echo e($index); ?>][number]" 
                                                   value="<?php echo e($achievement['number'] ?? ''); ?>"
                                                   placeholder="30,000+">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Tiêu đề</label>
                                            <input type="text" 
                                                   class="form-control" 
                                                   name="achievements[<?php echo e($index); ?>][title]" 
                                                   value="<?php echo e($achievement['title'] ?? ''); ?>"
                                                   placeholder="Học Viên">
                                        </div>
                                        <div class="col-md-5">
                                            <label class="form-label">Mô tả</label>
                                            <textarea class="form-control" 
                                                      name="achievements[<?php echo e($index); ?>][description]" 
                                                      rows="2"
                                                      placeholder="Mô tả thành tựu"><?php echo e($achievement['description'] ?? ''); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <input type="hidden" name="settings[about_achievements]" id="achievements_json">
                    </div>
                </div>
            </div>

            <!-- Hệ thống cơ sở -->
            <div class="col-lg-12 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-map-marker-alt me-2"></i>Hệ thống cơ sở
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php
                            $locationsSetting = $aboutSettings->where('key', 'about_locations')->first();
                            $locations = $locationsSetting ? json_decode($locationsSetting->value, true) : [];
                        ?>
                        
                        <div id="locations-container">
                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="location-item border rounded p-3 mb-3">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label class="form-label">Tên cơ sở</label>
                                            <input type="text" 
                                                   class="form-control" 
                                                   name="locations[<?php echo e($index); ?>][name]" 
                                                   value="<?php echo e($location['name'] ?? ''); ?>"
                                                   placeholder="Cơ Sở 1">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label">Địa chỉ</label>
                                            <textarea class="form-control" 
                                                      name="locations[<?php echo e($index); ?>][address]" 
                                                      rows="2"
                                                      placeholder="Địa chỉ cơ sở"><?php echo e($location['address'] ?? ''); ?></textarea>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label">Điện thoại</label>
                                            <input type="text" 
                                                   class="form-control" 
                                                   name="locations[<?php echo e($index); ?>][phone]" 
                                                   value="<?php echo e($location['phone'] ?? ''); ?>"
                                                   placeholder="0975.186.230">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label">Mô tả</label>
                                            <textarea class="form-control" 
                                                      name="locations[<?php echo e($index); ?>][description]" 
                                                      rows="2"
                                                      placeholder="Mô tả cơ sở"><?php echo e($location['description'] ?? ''); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <input type="hidden" name="settings[about_locations]" id="locations_json">
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body text-center">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-save me-2"></i>
                            Lưu Thông tin
                        </button>
                        <button type="reset" class="btn btn-secondary btn-lg ms-2">
                            <i class="fas fa-undo me-2"></i>
                            Khôi phục
                        </button>
                        <a href="<?php echo e(route('about')); ?>" target="_blank" class="btn btn-info btn-lg ms-2">
                            <i class="fas fa-eye me-2"></i>
                            Xem trang
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
        
        // Form submission handler
        document.getElementById('aboutForm').addEventListener('submit', function(e) {
            // Update JSON fields before submission
            updateCoreValuesJson();
            updateAchievementsJson();
            updateLocationsJson();
        });
    });
    
    function updateCoreValuesJson() {
        const coreValues = [];
        document.querySelectorAll('.core-value-item').forEach((item, index) => {
            const icon = item.querySelector(`input[name="core_values[${index}][icon]"]`).value;
            const title = item.querySelector(`input[name="core_values[${index}][title]"]`).value;
            const description = item.querySelector(`textarea[name="core_values[${index}][description]"]`).value;
            
            if (title.trim()) {
                coreValues.push({ icon, title, description });
            }
        });
        
        document.getElementById('core_values_json').value = JSON.stringify(coreValues);
    }
    
    function updateAchievementsJson() {
        const achievements = [];
        document.querySelectorAll('.achievement-item').forEach((item, index) => {
            const number = item.querySelector(`input[name="achievements[${index}][number]"]`).value;
            const title = item.querySelector(`input[name="achievements[${index}][title]"]`).value;
            const description = item.querySelector(`textarea[name="achievements[${index}][description]"]`).value;
            
            if (title.trim()) {
                achievements.push({ number, title, description });
            }
        });
        
        document.getElementById('achievements_json').value = JSON.stringify(achievements);
    }
    
    function updateLocationsJson() {
        const locations = [];
        document.querySelectorAll('.location-item').forEach((item, index) => {
            const name = item.querySelector(`input[name="locations[${index}][name]"]`).value;
            const address = item.querySelector(`textarea[name="locations[${index}][address]"]`).value;
            const phone = item.querySelector(`input[name="locations[${index}][phone]"]`).value;
            const description = item.querySelector(`textarea[name="locations[${index}][description]"]`).value;
            
            if (name.trim()) {
                locations.push({ name, address, phone, description });
            }
        });
        
        document.getElementById('locations_json').value = JSON.stringify(locations);
    }
    
    function resetToDefault() {
        if (confirm('Bạn có chắc chắn muốn khôi phục về cài đặt mặc định? Tất cả thay đổi hiện tại sẽ bị mất.')) {
            window.location.href = '<?php echo e(route("admin.about.reset")); ?>';
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\donpv\Desktop\English\english-learning-app\resources\views/admin/about/index.blade.php ENDPATH**/ ?>